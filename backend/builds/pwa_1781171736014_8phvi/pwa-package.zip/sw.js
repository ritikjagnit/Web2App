// Service Worker generated automatically by App Weaver PWA Platform
const CACHE_NAME = 'pwa-cache-1781171740585';
const ASSETS_TO_CACHE = [
    './',
    './index.html',
    './manifest.json',
    './pwa-register.js',
    './offline.html',
    './icons/icon-192x192.png',
    './icons/icon-512x512.png',
    './w/load.php',
    './static/apple-touch/wikipedia.png',
    './static/favicon/wikipedia.ico',
    './static/images/icons/enwiki-25.svg',
    './static/images/mobile/copyright/wikipedia-wordmark-en-25.svg',
    './static/images/mobile/copyright/wikipedia-tagline-en-25.svg',
    './wiki/Special:CentralAutoLogin/start',
    './static/images/footer/wikimedia.svg',
    './w/resources/assets/mediawiki_compact.svg'
];

// Install Event
self.addEventListener('install', (event) => {
    event.waitUntil(
        caches.open(CACHE_NAME).then((cache) => {
            console.log('[SW] Pre-caching offline pages and assets');
            return cache.addAll(ASSETS_TO_CACHE);
        }).then(() => self.skipWaiting())
    );
});

// Activate Event
self.addEventListener('activate', (event) => {
    event.waitUntil(
        caches.keys().then((cacheNames) => {
            return Promise.all(
                cacheNames.map((cache) => {
                    if (cache !== CACHE_NAME) {
                        console.log('[SW] Clearing old cache store:', cache);
                        return caches.delete(cache);
                    }
                })
            );
        }).then(() => self.clients.claim())
    );
});

// Fetch Event
self.addEventListener('fetch', (event) => {
    // Only cache GET requests
    if (event.request.method !== 'GET') return;
    
    // Skip external APIs or non-http requests
    if (!event.request.url.startsWith(self.location.origin)) return;

    
        // Stale While Revalidate Strategy
        event.respondWith(
            caches.match(event.request).then((cachedResponse) => {
                const fetchPromise = fetch(event.request).then((networkResponse) => {
                    if (networkResponse && networkResponse.status === 200) {
                        const responseToCache = networkResponse.clone();
                        caches.open(CACHE_NAME).then((cache) => {
                            cache.put(event.request, responseToCache);
                        });
                    }
                    return networkResponse;
                }).catch(() => {
                    // Suppress network error logs when offline
                });
                return cachedResponse || fetchPromise || caches.match('./offline.html');
            })
        );
});
