// Registers the service worker for instant installation
if ('serviceWorker' in navigator) {
    window.addEventListener('load', () => {
        navigator.serviceWorker.register('./sw.js')
            .then((reg) => {
                console.log('App Weaver PWA Service Worker Registered. Scope: ', reg.scope);
            })
            .catch((err) => {
                console.error('PWA Service Worker Registration Failed: ', err);
            });
    });
}
